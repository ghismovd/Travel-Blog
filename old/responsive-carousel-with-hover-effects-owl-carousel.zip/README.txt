A Pen created at CodePen.io. You can find this one at http://codepen.io/riogrande/pen/jqRQYy.

 Responsive carousel slider with owl carousel, hover effects and touch support made with owl carousel