A Pen created at CodePen.io. You can find this one at http://codepen.io/riogrande/pen/eZoQWG.

 Responsive carousel(slider) in full width with touch support using owl-carousel and ionicons